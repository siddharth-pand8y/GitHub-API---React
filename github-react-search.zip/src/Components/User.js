import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class User extends Component {
  constructor(props) {
    super(props);
  }

  renderStat(stat) {
    return (
      <li key={stat.name} className="user-info__stat">
        <Link to={stat.url}>
          <p className="user-info__stat-value">{stat.value}</p>
          <p className="user-info__stat-name">{stat.name}</p>
        </Link>
      </li>
    );
  }

  render() {
    const user = this.props.user;
    const stats = this.props.stats;
    return (
      <div className="user-page">
        <div className="user-info">
          <Link className="user-info__text" to={`/user/${user.login}`}>
            <img
              className="user-info__avatar"
              src={user.avatar_url}
              alt={`${user.login} avatar`}
            />
            <h2 className="user-info__title">
              {user.login} ({user.name})
            </h2>
            <p className="user-info__bio">{user.bio}</p>
          </Link>

          <ul className="user-info__stats">{stats.map(this.renderStat)}</ul>
        </div>
      </div>
    );
  }
}

export default User;
