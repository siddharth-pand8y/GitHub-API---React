import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class UserSearch extends Component {
  constructor(props) {
    super(props);

    this.state = {
      user: []
    };
  }

  componentDidMount() {
    if (this.props.query) {
      fetch(`https://api.github.com/search/users/?q=${this.props.query}`)
        .then(response => response.json())
        .then(user => {
          // How can we use `this` inside a callback without binding it??
          // Make sure you understand this fundamental difference with arrow functions!!!
          this.setState({
            user: user
          });
        });

      console.log(this.state.user.data[0]);
    }
  }

  render() {
    let query = this.props.query;

    return <div className="User-List" />;
  }
}

export default UserSearch;
